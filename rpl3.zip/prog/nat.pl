nat(zero).
nat(succ(X)) :- nat(X).
